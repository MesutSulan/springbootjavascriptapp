class Calculate {
	constructor(prevTxt,curentTxt){
		this.prevTxt = prevTxt
		this.curentTxt = curentTxt
		this.clear()
	}
	clear(){
		this.previousOperand = ''
		this.currentOperand = ''
		this.operation = undefined
	}
	delete(){this.currentOperand = this.currentOperand.toString().slice(0,-1)}
	calcPercent(){return this.currentOperand = parseFloat(this.currentOperand / 100)}
	sqrtFon(){return this.currentOperand = parseFloat(Math.sqrt(this.currentOperand)).toFixed(3)}
	cbrtFon(){return this.currentOperand = parseFloat(Math.cbrt(this.currentOperand)).toFixed(3)}
	roundFon(){return this.currentOperand = parseFloat(Math.round(this.currentOperand))}
	logFon(){return this.currentOperand = parseFloat(Math.log2(this.currentOperand)).toFixed(3)}
	piFon(){return this.currentOperand = parseFloat(Math.PI).toFixed(2)}


	chooseNumbers(number){
    if (number === '.' && this.currentOperand.includes('.')) return
    this.currentOperand = this.currentOperand.toString() + number.toString()
  }
	chooseOperations(operation){
		if(this.currentOperand === '' ) return
		if(this.previousOperand != ''){
			this.equals()
		}
		this.operation = operation
		this.previousOperand = this.currentOperand
		this.currentOperand = ''

	}

	equals(){
		let computation
		const prev = parseFloat(this.previousOperand)
		const current = parseFloat(this.currentOperand)
		if(isNaN(prev) || isNaN(current)) return
		switch(this.operation) {
			case '+':
			computation = prev + current
			break
			
			case '-':
			computation = prev - current
			break
			
			case '*':
			computation = prev * current
			break
			
			case '÷':
			computation = prev / current
			break

			case '^':
			computation = Math.pow(prev,current)
			break
			
			default:
			return
			
		}
		this.currentOperand = computation 
		this.operation = undefined
		this.previousOperand = ''

	}
	noWriteNum(number){
	    const stringNumber = number.toString()
	    const integerDigits = parseFloat(stringNumber.split('.')[0])
	    const decimalDigits = stringNumber.split('.')[1]
	    let integerDisplay
	    if (isNaN(integerDigits)) {
	      integerDisplay = ''
	    } else {
	      integerDisplay = integerDigits.toLocaleString('en', { maximumFractionDigits: 0 })
	    }
	    if (decimalDigits != null) {
	      return `${integerDisplay}.${decimalDigits}`
	    } else {
	      return integerDisplay
	    }
	  }
	reClear(){
		this.curentTxt.innerText = this.noWriteNum(this.currentOperand)
		if(this.operation != null ){
			this.prevTxt.innerText = `${this.noWriteNum(this.previousOperand)} ${this.operation}`
		} else { 
			this.prevTxt.innerText = ''
		}		
	}
}


const numberBtn = document.querySelectorAll('[data-number]')
const deleteBtn = document.querySelector('[data-delete]')
const allClearBtn = document.querySelector('[data-all-clear]')
const equalsBtn = document.querySelector('[data-equals]')
const operationBtn = document.querySelectorAll('[data-operation]')
const prevTxt = document.querySelector('[data-previous-operand]')
const curentTxt = document.querySelector('[data-current-operand]')
const pursent = document.querySelector('[data-percentage]')
const sqrt = document.querySelector('[data-sqrt]')
const cbrt = document.querySelector('[data-cbrt]')
const round = document.querySelector('[data-round]')
const log = document.querySelector('[data-log]')
const pi = document.querySelector('[data-PI]')
const pow = document.querySelector('[data-operation]')

const calculate = new Calculate(prevTxt,curentTxt)

numberBtn.forEach(button => {
	button.addEventListener('click', () => {
		calculate.chooseNumbers(button.innerText)
		calculate.reClear()
	})
})

operationBtn.forEach(button => {
	button.addEventListener('click', () => {
		calculate.chooseOperations(button.innerText)
		calculate.reClear()
	})
})

round.addEventListener('click', () => {
	calculate.roundFon()
	calculate.reClear()

})

equalsBtn.addEventListener('click' ,() =>{
	calculate.equals()
	calculate.reClear()
	
})

allClearBtn.addEventListener('click' , () =>{
	calculate.clear()
	calculate.reClear()
	
})

deleteBtn.addEventListener('click' ,() =>{
	calculate.delete()
	calculate.reClear()
	
})
pursent.addEventListener('click' ,() =>{
	calculate.calcPercent()
	calculate.reClear()
	
})
sqrt.addEventListener('click' ,() =>{
	calculate.sqrtFon()
	calculate.reClear()
	
})
cbrt.addEventListener('click' ,() =>{
	calculate.cbrtFon()
	calculate.reClear()
	
})

log.addEventListener('click' ,() =>{
	calculate.logFon()
	calculate.reClear()
	
})
pi.addEventListener('click', () => {
	calculate.piFon()
	calculate.reClear()
})
