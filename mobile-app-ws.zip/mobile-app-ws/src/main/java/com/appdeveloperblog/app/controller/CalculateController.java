package com.appdeveloperblog.app.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class CalculateController {

	@RequestMapping("/calculate") // http://localhost:8083/calculate
	public String calculate() {
		return "calculate12";
	}
}